---
license: cc-by-nc-sa-4.0
---

The copyright for this content belongs to its respective owners, and we do not claim any copyright rights over this data. This dataset has been released under the CC-BY-NC-SA-4.0 licence for non-commercial research purposes only. We are not liable for any monetary loss that may arise from the use of these datasets and model artefacts.

Files:

mb_ipo-reviews-final_data.xlsx : This is the main file for Mainboard

sme_ipo-reviews-final_data.xlsx : This is the main file for SME


In some cases, while creating json files, '&' in pdf file names has been replaced by ' '

sme_needed_jsons.zip : JSON files for SME IPOs. To be downloaded using this link: https://drive.google.com/file/d/1U9LQkmPXixsYRTnRw5Prs0mb9YpwsXWb/view?usp=sharing

mainboard_needed_jsons.zip : JSON files for Main board IPOs. To be downloaded using this link: https://drive.google.com/file/d/1j6yNZV0244qiBt3teJOmwI3slxHORhTw/view?usp=sharing

Code: ipo-review-longformerroberta-classify-summarised.ipynb


| **Column Name**        |                                                **Description** |
|------------------------|---------------------------------------------------------------:|
| key                    |                                  Unique identifier of each row |
| year                   |                                         Year of the IPO review |
| Review Title           |                                            Title of the review |
| review_text            |                                     Text content of the review |
| review_link            |                                             Link to the review |
| ipo_link               |                                    Link to the IPO information |
| most_relevant_link     |                               Link to access the (D)RHP report |
| Text_extracted_JSON    | name of JSON file with texts  extracted from the (D)RHP report |
| answer_of_question_0   |                                           Answer of Question 0 |
| answer_of_question_1   |                                           Answer of Question 1 |
| answer_of_question_2   |                                           Answer of Question 2 |
| answer_of_question_3   |                                           Answer of Question 3 |
| answer_of_question_4   |                                           Answer of Question 4 |
| answer_of_question_5   |                                           Answer of Question 5 |
| answer_of_question_6   |                                           Answer of Question 6 |
| answer_of_question_7   |                                           Answer of Question 7 |
| answer_of_question_8   |                                           Answer of Question 8 |
| answer_of_question_9   |                                           Answer of Question 9 |
| answer_of_question_10  |                                          Answer of Question 10 |
| answer_of_question_11  |                                          Answer of Question 11 |
| answer_of_question_12  |                                          Answer of Question 12 |
| answer_of_question_13  |                                          Answer of Question 13 |
| answer_of_question_14  |                                          Answer of Question 14 |
| answer_of_question_15  |                                          Answer of Question 15 |
| summary_of_all_answers |                                 Summary of all answers 0 to 15 |
| Recommendation         |        Apply, Neutral,  May apply, or Avoid  (Target Variable) |
| split                  |                                             train / test split |


**List of questions**

| **Question Number** | **Question**                                                                                                                                                                       |
|---------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 0                   | What is the price band and issue price of the IPO?                                                                                                                                 |
| 1                   | What is the issue size and how many shares are being issued as part of the IPO?                                                                                                    |
| 2                   | What is the implied market capitalization of the company after the IPO?                                                                                                            |
| 3                   | How will the company utilize the funds raised through the IPO, and what is the purpose of the IPO?                                                                                 |
| 4                   | What is the company's revenue growth rate over recent financial years, and how has its financial performance been historically (including revenue, EBITDA, and net profit trends)? |
| 5                   | What are the key financial ratios, such as net profit margin, return on equity (RoE), return on capital employed (RoCE), and total debt?                                           |
| 6                   | What is the shareholding pattern before and after the IPO, and who are the promoters?                                                                                              |
| 7                   | Are there any regulatory issues or conflicts of interest affecting the company?                                                                                                    |
| 8                   | What are the company's plans for expansion and future growth, and how does it position itself in terms of competition within its industry?                                         |
| 9                   | Who are the company's major customers, what is the revenue breakdown by sector, and is there a dependency on large institutional customers?                                        |
| 10                  | What are the potential risks associated with increasing raw material costs, and what other risks does the company face?                                                            |
| 11                  | How does the company's valuation compare to its peers, and is the issue priced aggressively compared to industry standards?                                                        |
| 12                  | What is the competitive landscape of the industry in which the company operates?                                                                                                   |
| 13                  | Has the company declared any dividends in the past, and what is its dividend policy?                                                                                               |
| 14                  | Who are the lead managers and registrar for the IPO, and what is their track record in terms of past IPO listings?                                                                 |
| 15                  | Are there any concerns regarding transparency or missing details in the offer document?                                                                                            |



