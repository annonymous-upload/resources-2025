---
license: cc-by-nc-sa-4.0
language:
- en
tags:
- finance
---


MiMIC_analysis_code.ipynb                               : This is the actual code file with results

MiMIC_Multi-Modal_Indian_Earnings_Calls.xlsx            : This is the main file having to be used for training. Descripton of columns of this file is given below.

getting_all_texts_together_embeddings_dim128_CPU.pkl    : This is the file having embeddings of texts (extracted from transcripts, images) and tables (extracted from images) concatenated one after the other.

getting_all_texts_together.pkl                          : This is the file having concatenated texts mentioned above.  This needs to be downloaded using the link: https://drive.google.com/file/d/1Sv7aEplpJDOMYcV66ClrPWVg_oRLWqqR/view?usp=sharing

image_embedding_mean_pooled_128_dim_CPU_df.csv          : This is the file having embeddings of images. For instances with multiple images, we have performed mean pooling.

extracted_texts.zip                            : This is the file having texts extracted from the transcripts and presentations. This needs to be downloaded using the link: https://drive.google.com/file/d/1G2rvNHs12Hu9yYbm8uxSGKmehxmhc_XM/view?usp=sharing

extracted_tables_from_images_new_filtered.zip  : This is the file having tables extracted from the presentations. This needs to be downloaded using the link: https://drive.google.com/file/d/1bEHlPgyZ0WmohOapNCnbPqHqtVj_8N-2/view?usp=sharing

extracted_images_new_filtered.zip              : This is the file having images extracted from the presentations. This needs to be downloaded using the link: https://drive.google.com/file/d/1ANQHXowNnbGS4zJphEzQHI1edRXN2cI4/view?usp=sharing

final_train.csv                                         : Final training file with text & image classifier probabilities

final_valid.csv                                         : Final validation file with text & image classifier probabilities

final_test.csv                                          : Final test file with text & image classifier probabilities

Best_Performing_Model_on_MiMIC.zip                      : Compressed version of best performing artifact 

Description of Columns
----------------------

| column_name                    | column_description                          |
|:-------------------------------|:--------------------------------------------|
| company_name                   | Name of the company                         |
| ticker                         | Ticker symbol of the company                |
| company_website_link           | Link to the company website                 |
| screener_link                  | Link to the screener                        |
| transcript_link                | Link to the transcript                      |
| transcript_file_name           | File name of the transcript                 |
| ppt_link                       | Link to the presentation                    |
| ppt_file_name                  | File name of the presentation               |
| RESULT DATE                    | Result date                                 |
| year                           | Year from Result date                       |
| month_numeric                  | Month from Result date                      |
| RESULT DATE open price         | Open price on the result date               |
| RESULT DATE+1                  | Date following the result date              |
| SMA20                          | Simple Moving Average of 20 periods         |
| SMA50                          | Simple Moving Average of 50 periods         |
| RSI14                          | Relative Strength Index                     |
| gdp_growth                     | GDP growth rate                             |
| inflation                      | Inflation rate                              |
| NIFTY50_open                   | NIFTY 50 open price                         |
| NIFTY50_close                  | NIFTY 50 close price                        |
| NIFTY50_volume                 | NIFTY 50 traded volume                      |
| previous_year                  | Previous year                               |
| financial_year                 | Financial year                              |
| Sales                          | Company Sales                               |
| Expenses                       | Expenses incurred by company                |
| Operating Profit               | Operating Profit                            |
| OPM %                          | Operating profit margin                     |
| Other Income                   | Other income sources                        |
| Interest                       | Interest expense                            |
| Depreciation                   | Depreciation expense                        |
| Profit before tax              | Profit before tax deduction                 |
| Tax %                          | Tax Percentage                              |
| Net Profit                     | Net Profit after tax                        |
| EPS in Rs                      | Earnings per share                          |
| Dividend Payout %              | Dividend payout ratio                       |
| Equity Capital                 | Equity capital                              |
| Reserves                       | Reserves held by the company                |
| Borrowings                     | Borrowings amount                           |
| Other Liabilities              | Other liabilities                           |
| Total Liabilities              | Total liabilities of company                |
| Fixed Assets                   | Fixed assets of company                     |
| CWIP                           | Capital Work in Progress                    |
| Investments                    | Investments held                            |
| Other Assets                   | Other assets                                |
| Total Assets                   | Total assets of company                     |
| Cash from Operating Activity   | Cash flow from operating activities         |
| Cash from Investing Activity   | Cash flow from investing activities         |
| Cash from Financing Activity   | Cash flow from financing activities         |
| Net Cash Flow                  | Net cash flow                               |
| Revenue                        | Revenue generated                           |
| Financing Profit               | Profit from financing activities            |
| Financing Margin %             | Financing Margin percentage                 |
| Deposits                       | Deposits amount                             |
| Borrowing                      | Borrowing amount                            |
| RESULT DATE+1 open price       | Open price on the next day                  |
| TARGET-2 REGRESSION NORMALIZED | Target variable for regression (normalized) |
| split                          | Data split (train, validation, test)        |

