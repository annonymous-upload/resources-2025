---
license: cc-by-nc-sa-4.0
task_categories:
- text-classification
tags:
- finance
- indian
size_categories:
- 1K<n<10K
---


Sector Classification Dataset: sector_classification/sectorwise_budget_text_extracted.xlsx <br>
Description of columns: <br>
date - Date of Budget <br>
year - Year of Budget <br>
budget_full_text_filename - Name of file having full budget transcript <br>
text_segment - Text excerpts related to the identified sector <br>
sector	- Identified sector (TARGET) <br>


Sector Ranking Dataset: sector_ranking/sectorwise_budgetdaywise_performance_with_text_ranked_full.xlsx <br>
Description of columns: <br>
date -                       Date of Budget	<br>
year -                       Year of Budget <br>
budget_full_text_filename -  Name of file having full budget transcript <br>
sector	-                    Identified sector <br>
text_segment	-            Text excerpts related to the identified sector <br>
number_of_companies	-        Number of companies in the identified sector for which we could get data <br>
mean_target_increment	-    Denotes the change in performance of sector on the day next to the budget day (TARGET) <br>
rank -                       Rank of the Sector in the given year (TARGET) <br>

Budget_Speech_Transcripts.zip is the full text transcripts file in raw format and it can be downloaded from the link: https://drive.google.com/file/d/168xI6wT6j9UqWVywwkdL8Rjpw4pUZWZa/view?usp=sharing
