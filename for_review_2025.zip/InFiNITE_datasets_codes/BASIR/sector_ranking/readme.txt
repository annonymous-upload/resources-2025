Description of columns:
date -                       Date of Budget	
year -                       Year of Budget
budget_full_text_filename -  Name of file having full budget transcript
sector	-                    Identified sector
text_segment	-            Text excerpts related to the identified sector
number_of_companies	-        Number of companies in the identified sector for which we could get data
mean_target_increment	-    Denotes the change in performance of sector on the day next to the budget day [TARGET]
rank -                       Rank of the Sector in the given year [TARGET]