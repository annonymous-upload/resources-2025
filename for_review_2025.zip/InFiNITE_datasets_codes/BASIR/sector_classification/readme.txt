Description of columns:
date - Date of Budget
year - Year of Budget
budget_full_text_filename - Name of file having full budget transcript
text_segment - Text excerpts related to the identified sector
sector	- Identified sector [TARGET]
